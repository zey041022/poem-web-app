#!/bin/bash

# 诗界2.0部署脚本

# 1. 创建项目目录
echo "创建项目目录..."
mkdir -p /opt/poetry_app
cd /opt/poetry_app

# 2. 安装Python和必要的系统依赖
echo "安装系统依赖..."
yum update -y
yum install -y python3 python3-pip python3-devel gcc

# 3. 创建并激活虚拟环境
echo "创建虚拟环境..."
python3 -m venv venv
source venv/bin/activate

# 4. 升级pip
echo "升级pip..."
pip install --upgrade pip

# 5. 安装项目依赖
echo "安装项目依赖..."
# 这里假设requirements.txt已经上传
pip install -r requirements.txt

# 6. 确保必要的目录存在
echo "创建必要的目录..."
mkdir -p uploads
mkdir -p static/images
mkdir -p static/js
mkdir -p static/css
mkdir -p static/fonts
mkdir -p templates

# 7. 设置文件权限
echo "设置文件权限..."
chmod -R 755 /opt/poetry_app

# 8. 启动应用
echo "启动Flask应用..."
# 使用nohup和&使其在后台运行
source venv/bin/activate
nohup gunicorn -w 4 -b 0.0.0.0:5000 app:app > app.log 2>&1 &
echo "应用已启动，PID: $!"

echo "部署完成！应用运行在 http://192.144.142.60:5000"
