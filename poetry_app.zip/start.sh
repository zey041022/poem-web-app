#!/bin/bash

# 设置工作目录
cd "$(dirname "$0")"

# 创建并激活虚拟环境
if [ ! -d "venv" ]; then
    echo "创建虚拟环境..."
    python3 -m venv venv
fi

echo "激活虚拟环境..."
source venv/bin/activate

# 升级pip
echo "升级pip..."
pip install --upgrade pip

# 安装依赖
echo "安装项目依赖..."
pip install -r requirements.txt

# 确保必要的目录存在
echo "创建必要的目录..."
mkdir -p uploads
mkdir -p static/images

# 确保.env文件存在
if [ ! -f ".env" ]; then
    echo "错误: .env文件不存在，请确保已上传.env文件"
    exit 1
fi

# 启动Flask应用（使用gunicorn）
echo "启动Flask应用..."
gunicorn -w 4 -b 0.0.0.0:5000 app:app